#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>
#include <omp.h>

#define NBT_IMPLEMENTATION
#include "nbt.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_RESIZE_IMPLEMENTATION
#include "stb_image_resize2.h"

static int findNearestBlockMatch(int oldR, int oldG, int oldB, const unsigned char *blockColors, int blockCount) {
    int mini = 0;
    int mindistance = 1000;

    int r, g, b, d, index;

    for (int i = 0; i < blockCount; i++) {
        index = i*3;
        r = blockColors[index];
        g = blockColors[index + 1];
        b = blockColors[index + 2];

        d = abs(r - oldR) + abs(g - oldG) + abs(b - oldB);

        if (d < mindistance) {
            mini = i;
            mindistance = d;

            if (d == 0) { break; }
        }
    }
    return mini;
}

static void diffuse(int eR, int eG, int eB, int pixel, unsigned char *img, double errorPercentage) {
    int R = img[pixel];
    int G = img[pixel + 1];
    int B = img[pixel + 2];
    R += eR * errorPercentage;
    G += eG * errorPercentage;
    B += eB * errorPercentage;
    img[pixel] = (unsigned char)(R < 0 ? 0 : (R > 255 ? 255 : R));
    img[pixel + 1] = (unsigned char)(G < 0 ? 0 : (G > 255 ? 255 : G));
    img[pixel + 2] = (unsigned char)(B < 0 ? 0 : (B > 255 ? 255 : B));
}

static int numberOfLeadingZeros(unsigned int x) {
    if (x == 0) return 32;
    int n = 0;
    if (x <= 0x0000FFFF) { n += 16; x <<= 16; }
    if (x <= 0x00FFFFFF) { n += 8;  x <<= 8;  }
    if (x <= 0x0FFFFFFF) { n += 4;  x <<= 4;  }
    if (x <= 0x3FFFFFFF) { n += 2;  x <<= 2;  }
    if (x <= 0x7FFFFFFF) { n += 1;  x <<= 1;  }
    return n;
}

static int max(int a, int b) {
    return (a > b) ? a : b;
}

// Packs block states into an array of 64-bit integers.
static int64_t* packBlockStates(const int* values, int values_len, int paletteSize, int* outLongCount) {
    int bitsPerBlock = max(2, 32 - numberOfLeadingZeros(paletteSize - 1));
    int totalBits = values_len * bitsPerBlock;
    int longCount = (totalBits + 63) / 64;
    
    // Allocating memory for the packed array
    int64_t* packed = (int64_t*)calloc(longCount, sizeof(int64_t));

    int bitIndex = 0;

    for (int i = 0; i < values_len; i++) {
        uint64_t value = (uint64_t)values[i];

        int longIndex = bitIndex >> 6;
        int startBit = bitIndex & 63;

        packed[longIndex] |= (int64_t)(value << startBit);

        if (startBit + bitsPerBlock > 64) {
            packed[longIndex + 1] |= (int64_t)(value >> (64 - startBit));
        }

        bitIndex += bitsPerBlock;
    }

    *outLongCount = longCount;
    return packed;
}

static void addBlockProperties(nbt_tag_t *block, char *propertiesString) {
    if (propertiesString == NULL || propertiesString[0] == '\0') {
        return;
    }

    char *temp = strchr(propertiesString, '=');
    if (temp == NULL) { return; }

    const char *key = propertiesString;
    size_t keyLength = temp - propertiesString;
    const char *value = temp + 1;
    size_t valueLength = strcspn(value, "~");

    nbt_tag_t *Properties = nbt_new_tag_compound();
    nbt_set_tag_name(Properties, "Properties", strlen("Properties"));
    nbt_tag_t *propertyTag = nbt_new_tag_string(value, valueLength);
    nbt_set_tag_name(propertyTag, key, keyLength);
    nbt_tag_compound_append(Properties, propertyTag);
    nbt_tag_compound_append(block, Properties);
}
static nbt_tag_t* packBlockPalette(char **blockRids, char **blockProperties, int blockRidsCount) {
    nbt_tag_t* tempTagList = nbt_new_tag_list(NBT_TYPE_COMPOUND);
    nbt_tag_t* air = nbt_new_tag_compound();
    nbt_set_tag_name(air, "Name", strlen("Name"));
    nbt_tag_t* airName = nbt_new_tag_string("minecraft:air", strlen("minecraft:air"));
    nbt_set_tag_name(airName, "Name", strlen("Name"));
    nbt_tag_compound_append(air, airName);
    nbt_tag_list_append(tempTagList, air);

    for (int i = 0; i < blockRidsCount; i++) {
            nbt_tag_t* block = nbt_new_tag_compound();
            nbt_tag_t* blockName = nbt_new_tag_string(blockRids[i], strlen(blockRids[i]));
            nbt_set_tag_name(blockName, "Name", strlen("Name"));
            nbt_tag_compound_append(block, blockName);
            addBlockProperties(block, blockProperties[i]);
            nbt_tag_list_append(tempTagList, block);
    }
    return tempTagList;
}

// https://github.com/Celisium/libnbt/blob/main/test.c
static size_t writer_write(void* userdata, uint8_t* data, size_t size) {
    return fwrite(data, 1, size, userdata);
}

static void write_nbt_file(const char* name, nbt_tag_t* tag, int flags) {

    FILE* file = fopen(name, "wb");

    nbt_writer_t writer;

    writer.write = writer_write;
    writer.userdata = file;

    nbt_write(writer, tag, flags);

    fclose(file);
}

static void nbtSchematic(int schematicWidth, int schematicHeight, int *results, int paletteSize, char **blockRids, char **blockProperties, int blockRidsCount, const char *outputSchematicPath) {

    // Creating root, MinecraftDataVersion and Version
    nbt_tag_t* root = nbt_new_tag_compound();
    nbt_set_tag_name(root, "", strlen(""));
    nbt_tag_t* MinecraftDataVersion = nbt_new_tag_int(4671);
    nbt_set_tag_name(MinecraftDataVersion, "MinecraftDataVersion", strlen("MinecraftDataVersion"));
    nbt_tag_t* Version = nbt_new_tag_int(7);
    nbt_set_tag_name(Version, "Version", strlen("Version"));
    nbt_tag_compound_append(root, MinecraftDataVersion);
    nbt_tag_compound_append(root, Version);

    // Creating Metadata
    nbt_tag_t* Metadata = nbt_new_tag_compound();
    nbt_set_tag_name(Metadata, "Metadata", strlen("Metadata"));
    nbt_tag_t* TimeCreated = nbt_new_tag_long(time(NULL));
    nbt_set_tag_name(TimeCreated, "TimeCreated", strlen("TimeCreated"));
    nbt_tag_t* TimeModified = nbt_new_tag_long(time(NULL));
    nbt_set_tag_name(TimeModified, "TimeModified", strlen("TimeModified"));
    nbt_tag_t* EnclosingSize = nbt_new_tag_compound();
    nbt_set_tag_name(EnclosingSize, "EnclosingSize", strlen("EnclosingSize"));
    nbt_tag_t* x = nbt_new_tag_int(1);
    nbt_set_tag_name(x, "x", strlen("x"));
    nbt_tag_t* y = nbt_new_tag_int(schematicHeight);
    nbt_set_tag_name(y, "y", strlen("y"));
    nbt_tag_t* z = nbt_new_tag_int(schematicWidth);
    nbt_set_tag_name(z, "z", strlen("z"));
    nbt_tag_t* Description = nbt_new_tag_string("Generated With Pixel Art Generator", strlen("Generated With Pixel Art Generator"));
    nbt_set_tag_name(Description, "Description", strlen("Description"));
    nbt_tag_t* previewImageData = nbt_new_tag_int_array(NULL, 0);
    nbt_set_tag_name(previewImageData, "PreviewImageData", strlen("PreviewImageData"));
    nbt_tag_t* RegionCount = nbt_new_tag_int(1);
    nbt_set_tag_name(RegionCount, "RegionCount", strlen("RegionCount"));
    nbt_tag_t* TotalBlocks = nbt_new_tag_int(schematicWidth * schematicHeight);
    nbt_set_tag_name(TotalBlocks, "TotalBlocks", strlen("TotalBlocks"));
    nbt_tag_t* Author = nbt_new_tag_string("some1", strlen("some1"));
    nbt_set_tag_name(Author, "Author", strlen("Author"));
    nbt_tag_t* TotalVolume = nbt_new_tag_int(schematicWidth * schematicHeight);
    nbt_set_tag_name(TotalVolume, "TotalVolume", strlen("TotalVolume"));
    nbt_tag_t* Software = nbt_new_tag_string("Pixel Art Generator by Marios", strlen("Pixel Art Generator by Marios"));
    nbt_set_tag_name(Software, "Software", strlen("Software"));
    nbt_tag_t* Name = nbt_new_tag_string("image", strlen("image"));
    nbt_set_tag_name(Name, "Name", strlen("Name"));

    // Packing BlockStates and BlockStatePalette
    nbt_tag_t* Regions = nbt_new_tag_compound();
    nbt_set_tag_name(Regions, "Regions", strlen("Regions"));
    nbt_tag_t* MainRegion = nbt_new_tag_compound();
    nbt_set_tag_name(MainRegion, "Main", strlen("Main"));
    int outLongCount;
    int64_t *outLong = packBlockStates(results, schematicHeight*schematicWidth, paletteSize, &outLongCount);
    nbt_tag_t* BlockStates = nbt_new_tag_long_array(outLong, outLongCount);
    nbt_set_tag_name(BlockStates, "BlockStates", strlen("BlockStates"));
    nbt_tag_t* BlockStatePalette = packBlockPalette(blockRids, blockProperties, blockRidsCount);
    nbt_set_tag_name(BlockStatePalette, "BlockStatePalette", strlen("BlockStatePalette"));

    nbt_tag_t* Position = nbt_new_tag_compound();
    nbt_set_tag_name(Position, "Position", strlen("Position"));
    nbt_tag_t* position_x = nbt_new_tag_int(0);
    nbt_set_tag_name(position_x, "x", strlen("x"));
    nbt_tag_t* position_y = nbt_new_tag_int(0);
    nbt_set_tag_name(position_y, "y", strlen("y"));
    nbt_tag_t* position_z = nbt_new_tag_int(0);
    nbt_set_tag_name(position_z, "z", strlen("z"));
    nbt_tag_t* RegionSize = nbt_new_tag_compound();
    nbt_set_tag_name(RegionSize, "Size", strlen("Size"));
    nbt_tag_t* region_size_x = nbt_new_tag_int(1);
    nbt_set_tag_name(region_size_x, "x", strlen("x"));
    nbt_tag_t* region_size_y = nbt_new_tag_int(schematicHeight);
    nbt_set_tag_name(region_size_y, "y", strlen("y"));
    nbt_tag_t* region_size_z = nbt_new_tag_int(schematicWidth);
    nbt_set_tag_name(region_size_z, "z", strlen("z"));
    
    
    nbt_tag_compound_append(Metadata, Description);
    nbt_tag_compound_append(Metadata, previewImageData);
    nbt_tag_compound_append(Metadata, RegionCount);
    nbt_tag_compound_append(Metadata, TotalBlocks);
    nbt_tag_compound_append(Metadata, Author);
    nbt_tag_compound_append(Metadata, TotalVolume);
    nbt_tag_compound_append(Metadata, Software);
    nbt_tag_compound_append(Metadata, Name);
    nbt_tag_compound_append(EnclosingSize, x);
    nbt_tag_compound_append(EnclosingSize, y);
    nbt_tag_compound_append(EnclosingSize, z);
    nbt_tag_compound_append(Metadata, EnclosingSize);
    nbt_tag_compound_append(Metadata, TimeCreated);
    nbt_tag_compound_append(Metadata, TimeModified);
    nbt_tag_compound_append(MainRegion, BlockStates);
    nbt_tag_compound_append(MainRegion, BlockStatePalette);
    nbt_tag_compound_append(Position, position_x);
    nbt_tag_compound_append(Position, position_y);
    nbt_tag_compound_append(Position, position_z);
    nbt_tag_compound_append(MainRegion, Position);
    nbt_tag_compound_append(RegionSize, region_size_x);
    nbt_tag_compound_append(RegionSize, region_size_y);
    nbt_tag_compound_append(RegionSize, region_size_z);
    nbt_tag_compound_append(MainRegion, RegionSize);

    nbt_tag_t* PendingBlockTicks = nbt_new_tag_list(NBT_TYPE_COMPOUND);
    nbt_set_tag_name(PendingBlockTicks, "PendingBlockTicks", strlen("PendingBlockTicks"));
    nbt_tag_t* PendingFluidTicks = nbt_new_tag_list(NBT_TYPE_COMPOUND);
    nbt_set_tag_name(PendingFluidTicks, "PendingFluidTicks", strlen("PendingFluidTicks"));
    nbt_tag_t* TileEntities = nbt_new_tag_list(NBT_TYPE_COMPOUND);
    nbt_set_tag_name(TileEntities, "TileEntities", strlen("TileEntities"));
    nbt_tag_t* Entities = nbt_new_tag_list(NBT_TYPE_COMPOUND);
    nbt_set_tag_name(Entities, "Entities", strlen("Entities"));

    nbt_tag_compound_append(MainRegion, PendingBlockTicks);
    nbt_tag_compound_append(MainRegion, PendingFluidTicks);
    nbt_tag_compound_append(MainRegion, TileEntities);
    nbt_tag_compound_append(MainRegion, Entities);
    nbt_tag_compound_append(Regions, MainRegion);
    nbt_tag_compound_append(root, Metadata);
    nbt_tag_compound_append(root, Regions);
    nbt_tag_t* subversion = nbt_new_tag_int(1);
    nbt_set_tag_name(subversion, "SubVersion", strlen("SubVersion"));
    nbt_tag_compound_append(root, subversion);
    
    write_nbt_file(outputSchematicPath, root, NBT_WRITE_FLAG_USE_GZIP);
}
// https://stackoverflow.com/questions/13218824/how-to-write-a-dll-file-in-c
__declspec(dllexport)
void generator(const char *imagePath, int width, int height, const unsigned char *blockColors, int blockCount, int useDithering, char **blockRids, char **blockProperties, int blockRidsCount, const char *outputSchematicPath) {
    int imageWidth, imageHeight, imageChannels;
    int channels = 4; // 4 channels for RGBA mode

    // Flip, load and resize image
    stbi_set_flip_vertically_on_load(1);
    unsigned char *image = stbi_load(imagePath, &imageWidth, &imageHeight, &imageChannels, channels);
    unsigned char *resizedImage = malloc((size_t)width * height * 4);
    stbir_resize_uint8_linear(image, imageWidth, imageHeight, 0, resizedImage, width, height, 0, STBIR_RGBA);
    stbi_image_free(image);
    image = resizedImage;

    int *results = malloc((size_t)width*height * sizeof(int));

    // If the user selected to use dithering, first we dither the image and then we find the best blocks and return them to the main python program.
    if (useDithering) {
        int oldR, oldG, oldB, alpha, paletteIndex, errorR, errorG, errorB;
        int newR, newG, newB;
        double R, G, B;
        int pixel;
        // Floyd-Steinberg Dithering: https://en.wikipedia.org/wiki/Floyd%E2%80%93Steinberg_dithering

        for (int h = 0; h < height - 1; h++) {
            for (int w = 1; w < width - 1; w++) {
                pixel = (h * width + w)*4;
                oldR = image[pixel];
                oldG = image[pixel + 1];
                oldB = image[pixel + 2];
                alpha = image[pixel + 3];
                if (alpha <= 0) { continue; }
                
                paletteIndex = findNearestBlockMatch(oldR, oldG, oldB, blockColors, blockCount);
                paletteIndex *= 3;
                newR = blockColors[paletteIndex];
                newG = blockColors[paletteIndex + 1];
                newB = blockColors[paletteIndex + 2];

                errorR = oldR - newR;
                errorG = oldG - newG;
                errorB = oldB - newB;

                diffuse(errorR, errorG, errorB, (h * width + (w + 1))*4, image, 0.4375);
                diffuse(errorR, errorG, errorB, ((h + 1) * width + (w - 1))*4, image, 0.1875);
                diffuse(errorR, errorG, errorB, ((h + 1) * width + w)*4, image, 0.3125);
                diffuse(errorR, errorG, errorB, ((h + 1) * width + (w + 1))*4, image, 0.0625);
            }
        }
    }

    // Finding closest block match for every pixel
    #pragma omp parallel for
    for (int pixel = 0; pixel < width * height; pixel++) {
        int r = image[pixel * 4];
        int g = image[pixel * 4 + 1];
        int b = image[pixel * 4 + 2];
        int a = image[pixel * 4 + 3];

        if (a == 0) {
            results[pixel] = 0;
            continue;
        }

        int mini = 0;
        int minDistance = 1000;
        
        for (int block = 0; block < blockCount; block++) {
            int br = blockColors[block * 3];
            int bg = blockColors[block * 3 + 1];
            int bb = blockColors[block * 3 + 2];

            int d = abs(r - br) + abs(g - bg) + abs(b - bb);

            if (d < minDistance) {
                minDistance = d;
                mini = block;

                if (d == 0) { break; }
            }
        }
        results[pixel] = mini + 1;
    }

    nbtSchematic(width, height, results, blockCount + 1, blockRids, blockProperties, blockRidsCount, outputSchematicPath);
    free(results);
    free(image);
}