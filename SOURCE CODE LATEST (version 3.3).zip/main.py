from __future__ import annotations
import os
import csv
import sys
from time import perf_counter
from tkinter import filedialog, ttk, Spinbox
from PIL import Image as Img # type: ignore
from PIL import ImageTk as ImgTk # type: ignore
from threading import Thread

import disable_buttons
import enable_buttons
import textures
import schematicPreview

import customtkinter as ctk # type: ignore
import ctypes
import numpy as np # type: ignore

WINDOW_WIDTH: int = 500
WINDOW_HEIGHT: int = 400
BLACK: str = "#000000"
WHITE: str = "#FFFFFF"
GRAY: str = "#d4d4d4"
PURPLE: str = "#8516b5"
RED: str = "#FF0000"
STATE_NORMAL: str = "normal"
STATE_DISABLED: str = "disabled"

def resourcePath(relativePath: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        basePath = sys._MEIPASS # type: ignore
    else:
        basePath = os.path.dirname(os.path.abspath(__file__))

    return os.path.join(basePath, relativePath)

def getProgramDirectory() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)

    return os.path.dirname(os.path.abspath(__file__))

class App(ctk.CTk):

    photoFilePath: str = ""
    photoFileName: str = ""
    schematicWidth: int = 0
    schematicHeight: int = 0
    defaultCSVFile: str = resourcePath("csv.csv")
    checkButtonVars: list[ctk.IntVar] = []
    startGenerateTime: int | float = 0
    endGenerateTime: int | float = 0
    lastSchematic: str = ""
    _dll = None
    schematicSaverJar: str = resourcePath("schematicSaver.jar")

    img = None

    def __init__(self) -> None:
        super().__init__()

        self.selectBlocksWindow = None
        self.useDithering: ctk.IntVar = ctk.IntVar(value=0)

        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.geometry("+650+300")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.onClosing)
        self.title("Pixel Art Generator")
        self.__setattr__("bg", BLACK)
        self.grid_rowconfigure(0, minsize=38)

        self.PixelArtGeneratorLabel: ctk.CTkLabel = ctk.CTkLabel(self, text="Pixel Art Generator Version 3.3", fg_color="light green", text_color=BLACK, corner_radius=5, width=100)
        self.PixelArtGeneratorLabel.place(relx=0.5, y=5, anchor="n")

        self.selectPhotoButton = ctk.CTkButton(self, text="Select photo", command=self.getPhotoFilePath)
        self.selectPhotoButton.grid(row=1, column=0, sticky="w", padx=10, pady=2)
        self.selectPhotoButtonLabel: ctk.CTkLabel = ctk.CTkLabel(self, text=f"Selected photo: {App.photoFilePath}", wraplength=330)
        self.selectPhotoButtonLabel.grid(row=1, column=1, sticky="w", pady=2)

        self.schematicWidthSpinbox: Spinbox = Spinbox(self, from_=10, to=1000, width=20, relief="sunken", fg="black", command=self.updateSchematicWidthFromSpinbox)
        self.schematicWidthSpinbox.config(state="normal", justify="center", wrap=True)
        self.schematicWidthSpinbox.grid(row=3, column=0, sticky="we", padx=11, pady=2)
        self.schematicWidthSpinboxLabel: ctk.CTkLabel = ctk.CTkLabel(self, text="Schematic Width (10 - 1000)")
        self.schematicWidthSpinboxLabel.grid(row=3, column=1, sticky="w", pady=2)

        self.schematicHeightSpinbox: Spinbox = Spinbox(self, from_=10, to=1000, width=20, relief="sunken", fg="black", command=self.updateSchematicHeightFromSpinbox)
        self.schematicHeightSpinbox.config(state="normal", justify="center", wrap=True)
        self.schematicHeightSpinbox.grid(row=4, column=0, sticky="we", padx=11, pady=2)
        self.schematicHeightSpinboxLabel: ctk.CTkLabel = ctk.CTkLabel(self, text="Schematic Height (10 - 1000)")
        self.schematicHeightSpinboxLabel.grid(row=4, column=1, sticky="w", pady=2)

        self.generateButton: ctk.CTkButton = ctk.CTkButton(self, text="Generate schematic!", command=self.startGenerator)
        self.generateButton.grid(row=5, column=0, sticky="we", padx=10, pady=2)

        self.selectBlocksButton: ctk.CTkButton = ctk.CTkButton(self, text="Select blocks", command=self.openSelectBlocksWindow)
        self.selectBlocksButton.grid(row=6, column=0, sticky="we", padx=10, pady=2)

        self.showSchematicButton: ctk.CTkButton = ctk.CTkButton(self, text="Show schematic", command=self.startSchematicPreview)
        self.showSchematicButton.grid(row=6, column=1, sticky="w", padx=10, pady=10)
        self.showSchematicWarningLabel: ctk.CTkLabel = ctk.CTkLabel(self, text="WARNING!\nShowing the schematic uses A LOT OF RAM.\nUSE AT YOUR OWN RISK!", fg_color=RED, text_color=BLACK, height=30)
        self.showSchematicWarningLabel.grid(row=7, column=1, sticky="w")

        self.useDitheringCheckbutton: ttk.Checkbutton = ttk.Checkbutton(self, text="Use Dithering?", variable=self.useDithering)
        self.useDitheringCheckbutton.grid(row=7, column=0, sticky="w", padx=10, pady=(10, 5))

        App.messageLabel = ctk.CTkLabel(self, fg_color=WHITE, text_color=BLACK, text="Program messages", height=90, width=480, wraplength=400)
        App.messageLabel.place(x=10, y=300)

    def openSelectBlocksWindow(self) -> None:
        if (self.selectBlocksWindow is not None and self.selectBlocksWindow.winfo_exists()): # type: ignore
            self.selectBlocksWindow.lift() # type: ignore
            self.selectBlocksWindow.focus_force() # type: ignore
            return

        self.selectBlocksWindow = BlocksWindow(self, fg_color=GRAY)

    def getPhotoFilePath(self) -> None:
        App.photoFilePath = filedialog.askopenfilename(title="Photo selection", filetypes=
            [
            ("Image files", "*.png *.jpg *.jpeg"),
            ("PNG files", "*.png"),
            ("All files", "*.*")
            ]
        )

        self.selectPhotoButtonLabel.configure(text=f"Selected photo: {App.photoFilePath.split("/")[-1]}")
        self.changeProgramMessage(f"Photo updated: {App.photoFilePath.split("/")[-1]}")

    def updateSchematicWidthFromSpinbox(self) -> None:
        try:
            temp = int(self.schematicWidthSpinbox.get())
        except:
            App.schematicWidth = 10
            return
        if (temp < 10): App.schematicWidth = 10
        elif (temp > 1000): App.schematicWidth = 1000
        else: App.schematicWidth = temp
        # App.schematicWidth = temp
    def updateSchematicHeightFromSpinbox(self) -> None:
        try:
            temp = int(self.schematicHeightSpinbox.get())
        except:
            App.schematicHeight = 10
            return
        if (temp < 10): App.schematicHeight = 10
        elif (temp > 1000): App.schematicHeight = 1000
        else: App.schematicHeight = temp
        # App.schematicHeight = temp
    def onClosing(self, *args) -> None:
        self.destroy()

    @staticmethod
    def changeProgramMessage(newMessage: str) -> None:
        App.messageLabel.configure(text=newMessage)

    def startGenerator(self) -> None:
        self.generateButton.configure(state=STATE_DISABLED)
        self.showSchematicButton.configure(state=STATE_DISABLED)
        self.changeProgramMessage("Generating...")
        Thread(target=self.generator, daemon=True).start()
    def endGenerator(self) -> None:
        self.generateButton.configure(state=STATE_NORMAL)
        self.showSchematicButton.configure(state=STATE_NORMAL)
    def startSchematicPreview(self) -> None:
        self.generateButton.configure(state=STATE_DISABLED)
        self.showSchematicButton.configure(state=STATE_DISABLED)
        self.changeProgramMessage("Loading Schematic preview...")
        Thread(target=self.runSchematicPreview, daemon=True).start()
    def runSchematicPreview(self) -> None:
        schematicPreview.schematicPreview(App.lastSchematic)
        self.after(0, self.endSchematicPreview)
    def endSchematicPreview(self) -> None:
        self.generateButton.configure(state=STATE_NORMAL)
        self.showSchematicButton.configure(state=STATE_NORMAL)
        self.changeProgramMessage("Loading done.")

    def generator(self) -> None:
        App.startGenerateTime = perf_counter()
        if (Palette.activeBlockList.__len__() == 0):
            App.changeProgramMessage("Please select at least one block!")
            self.showSchematicButton.configure(state=STATE_NORMAL)
            self.generateButton.configure(state=STATE_NORMAL)
            return
        if (App.photoFilePath == ""):
            App.changeProgramMessage("No photo selected! Can't generate schematic :(")
            self.showSchematicButton.configure(state=STATE_NORMAL)
            self.generateButton.configure(state=STATE_NORMAL)
            return
        try:
            Img.open(App.photoFilePath).close()
        except:
            self.selectPhotoButtonLabel.configure(text="Wrong file type, please select a photo with a valid file type")
            self.showSchematicButton.configure(state=STATE_NORMAL)
            self.generateButton.configure(state=STATE_NORMAL)
            return
        
        self.updateSchematicWidthFromSpinbox()
        self.updateSchematicHeightFromSpinbox()
        
        # Getting the block colors ready for the C program
        blockColors = np.array([[b.average.RED, b.average.GREEN, b.average.BLUE] for b in Palette.activeBlockList], dtype=np.uint8).ravel()
        blockRidBytes = [block.rid.encode("utf-8") for block in Palette.activeBlockList]
        blockRidsCount = blockRidBytes.__len__()

        # Converting data to C data types
        blockColorArray = blockColors.ctypes.data_as(ctypes.POINTER(ctypes.c_ubyte))
        blockRids = (ctypes.c_char_p * blockRidsCount)(*blockRidBytes)

        outputDirectory = os.path.join(getProgramDirectory(), "output schematics")
        os.makedirs(outputDirectory, exist_ok=True)
        outputSchematicPath = os.path.join(outputDirectory, f"{os.path.splitext(os.path.basename(App.photoFilePath))[0]}.litematic")

        # Running the C generator.
        App._dll.generator( # type: ignore
            App.photoFilePath.encode("utf-8"),
            self.schematicWidth,
            self.schematicHeight,
            blockColorArray,
            len(Palette.activeBlockList),
            self.useDithering.get(),
            blockRids,
            blockRidsCount,
            outputSchematicPath.encode("utf-8")
        )
        
        App.lastSchematic = outputSchematicPath
        
        App.endGenerateTime = perf_counter()
        self.changeProgramMessage(f"Generated! Time: {(App.endGenerateTime - App.startGenerateTime):.3f} seconds")

        # Performance Messages
        print(f"{App.schematicWidth} | {App.schematicHeight}")
        print("---------------------")
        print(f"C:  {App.endGenerateTime - App.startGenerateTime:.3f}s")
        print("---------------------")
        self.after(0, self.endGenerator)

    @staticmethod
    def getBlockMatcherDll() -> None:
        if App._dll is None:
            App._dll = ctypes.CDLL(resourcePath("C_backend\\generator.dll"))
            App._dll.generator.argtypes = [
                ctypes.c_char_p,                     # imagePath
                ctypes.c_int,                        # width
                ctypes.c_int,                        # height
                ctypes.POINTER(ctypes.c_ubyte),      # blockColors
                ctypes.c_int,                        # blockCount
                ctypes.c_int,                        # useDithering
                ctypes.POINTER(ctypes.c_char_p),     # blockRids
                ctypes.c_int,                        # blockRidsCount
                ctypes.c_char_p                      # output Schematic path
            ]

            App._dll.generator.restype = ctypes.c_int
        
    @staticmethod
    def readCSV() -> None:
        with open(App.defaultCSVFile, newline='') as f:
            reader = csv.reader(f, delimiter=",", quoting=csv.QUOTE_NONE)
            for row in reader:
                if ("RID" in row): continue
                if ("concrete_powder" in row[0]):
                    Palette.concretePowder.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                elif ("concrete" in row[0]):
                    Palette.concreteBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                elif ("wool" in row[0]):
                    Palette.woolBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                elif ("glazed_terracotta" in row[0]):
                    Palette.glazedTerracottaBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                elif ("terracotta" in row[0]):
                    Palette.terracottaBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                elif ("log" in row[0]):
                    Palette.logBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                elif ("planks" in row[0]):
                    Palette.plankBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
                else:
                    Palette.allTheOtherBlocks.append(MinecraftBlock(RGBCOLOR(int(row[1]), int(row[2]), int(row[3])), row[0], App.parse(row[4])))
        
        Palette.updateAllBlocksList()
        Palette.activeBlockList = Palette.allBlocksList.copy()
        App.checkButtonVars = [ctk.IntVar(value=1) for i in range(Palette.allBlocksList.__len__())]

    @staticmethod
    def constructStringFromDict(d: dict[str, str]) -> str:
        x: str = ""
        for v in d:
            x += f"{v}={d[v]}~"
        return x
    
    @staticmethod
    def parse(s: str) -> dict[str, str]:
        if (s.__len__() == 0):
            return {}
        d = {}
        L: list = s.split("~")[0:-1]
        for value in L:
            x, y = value.split("=")
            d[x] = y
        return d


class BlocksWindow(ctk.CTkToplevel):

    checkButtons: list[ttk.Checkbutton] = []
    textureImagesTk = {}

    def __init__(self, parent: App, *args, fg_color: str | tuple[str, str] | None = None, **kwargs) -> None:
        super().__init__(parent, fg_color=fg_color, *args, **kwargs)
        self.parent = parent

        BlocksWindow.checkButtons.clear()

        # Style settings so the ttk.Checkbuttons have the same white as the background of the CtkFrame
        self.checkboxStyle = ttk.Style()
        self.checkboxStyle.configure("Blocks.TCheckbutton",background=GRAY)
        self.checkboxStyle.map("Blocks.TCheckbutton",background=[
                                                                ("active", GRAY),
                                                                ("selected", GRAY),
                                                                ("!selected", GRAY)
                                                                ])

        self.geometry(f"{1840}x{900}+100+50")
        self.geometry("+50+50")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.closeSelectBlocksWindow)
        self.title("Block selection")

        #Making the window scrollable without having to put the mouse on the scrollbar
        self.bind("<MouseWheel>", self.onMouseWheel)

        self.canvas = ctk.CTkCanvas(self, bg=GRAY, bd=0, highlightthickness=0, relief="flat")
        self.canvas.pack(side=ctk.LEFT, fill=ctk.BOTH, expand=True, padx=0, pady=0)
        self.scrollable_frame = ctk.CTkFrame(self.canvas, fg_color=GRAY, corner_radius=0, border_width=0)
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self.saveBlockList = ctk.CTkButton(self.scrollable_frame, text="Save blocks", command=self.updateAvailableBlockList)
        self.saveBlockList.place(x=10, y=600)

        # Creating Block Categories
        index: int = 0
        
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "CONCRETE POWDER", Palette.concretePowder, 0, index, lambda: disable_buttons.disableConcretePowderBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enableConcretePowderBlocks(BlocksWindow.checkButtons, App.checkButtonVars))
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "CONCRETE", Palette.concreteBlocks, 1, index, lambda: disable_buttons.disableConcreteBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enableConcreteBlocks(BlocksWindow.checkButtons, App.checkButtonVars))
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "WOOL", Palette.woolBlocks, 2, index, lambda: disable_buttons.disableWoolBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enableWoolBlocks(BlocksWindow.checkButtons, App.checkButtonVars))
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "TERRACOTTA", Palette.terracottaBlocks, 3, index, lambda: disable_buttons.disableTerracottaBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enableTerracottaBlocks(BlocksWindow.checkButtons, App.checkButtonVars))
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "GLAZED TERRACOTTA", Palette.glazedTerracottaBlocks, 4, index, lambda: disable_buttons.disableGlazedTerracottaBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enableGlazedTerracottaBlocks(BlocksWindow.checkButtons, App.checkButtonVars))
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "LOGS", Palette.logBlocks, 5, index, lambda: disable_buttons.disableLogBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enableLogBlocks(BlocksWindow.checkButtons, App.checkButtonVars))
        index = BlocksWindow.createBlockCategory(self.scrollable_frame, "PLANKS", Palette.plankBlocks, 6, index, lambda: disable_buttons.disablePlankBlocks(BlocksWindow.checkButtons, App.checkButtonVars), lambda: enable_buttons.enablePlankBlocks(BlocksWindow.checkButtons, App.checkButtonVars))

        # OTHER BLOCKS
        cln = 0
        temp_indexX = 0
        temp_indexY = 0
        self.temp_frame = ctk.CTkFrame(self.scrollable_frame, fg_color=GRAY)
        self.temp_frame.grid(row=0, column=7, sticky="n", padx=5)
        ctk.CTkLabel(self.temp_frame, text="OTHER BLOCKS", fg_color=BLACK, text_color=GRAY, width=625, corner_radius=5).grid(row=0, column=0, sticky="wn", columnspan=3, pady=2)
        for i in range(Palette.allTheOtherBlocks.__len__()):
            BlocksWindow.checkButtons.append(ttk.Checkbutton(self.temp_frame, text=f"{Palette.allTheOtherBlocks[i].name.replace("_", " ")}", variable=App.checkButtonVars[index], image=BlocksWindow.textureImagesTk[Palette.allTheOtherBlocks[i].name.replace("_", " ")], compound="left", style="Blocks.TCheckbutton", ))
            BlocksWindow.checkButtons[index].grid(row=temp_indexX+1, column=cln, sticky="w", pady=2, padx=(0,20))
            if temp_indexY == 46:
                temp_indexX = -1
                temp_indexY = 0
                cln += 1
            index += 1
            temp_indexY += 1
            temp_indexX += 1

    @staticmethod
    def createBlockCategory(parent: ctk.CTkFrame, title: str, blocks, cln: int, index: int, *args):
        frameeeee = ctk.CTkFrame(parent, fg_color=GRAY)
        frameeeee.grid(row=0, column=cln, sticky="n", padx=5)
        frameeeee.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(frameeeee, text=title, fg_color=BLACK, text_color=WHITE, corner_radius=5).grid(row=0, column=0, sticky="ew", pady=2)

        for i in range(len(blocks)):
            blockname = blocks[i].rid[10:].replace("_", " ")
            BlocksWindow.checkButtons.append(ttk.Checkbutton(frameeeee, text=blockname, variable=App.checkButtonVars[index], image=BlocksWindow.textureImagesTk[blockname], compound="left", style="Blocks.TCheckbutton"))
            BlocksWindow.checkButtons[index].grid(row = i + 1, column=0, sticky="w", pady=2)

            index += 1
            
        ctk.CTkButton(frameeeee, text=f"disable {title.lower()}", command=args[0]).grid(row=len(blocks) + 1, column=0, sticky="we", padx=5, pady=(10,2))
        ctk.CTkButton(frameeeee, text=f"enable {title.lower()}", command=args[1]).grid(row=len(blocks) + 2, column=0, sticky="we", padx=5, pady=2)

        if (cln == 6):
            ctk.CTkButton(frameeeee, text="disable other blocks", command=lambda: disable_buttons.disableOtherBlocks(BlocksWindow.checkButtons, App.checkButtonVars, Palette.allTheOtherBlocks)).grid(row=len(blocks) + 3, column=0, sticky="w", pady=(400,2))
            ctk.CTkButton(frameeeee, text="enable other blocks", command=lambda: enable_buttons.enableOtherBlocks(BlocksWindow.checkButtons, App.checkButtonVars, Palette.allTheOtherBlocks)).grid(row=len(blocks) + 4, column=0, sticky="w", pady=2)

        return index

    @staticmethod
    def CreateTextures() -> None:
        for block in Palette.allBlocksList:
            BlocksWindow.textureImagesTk[block.name.replace("_", " ")] = ImgTk.PhotoImage(textures.Textures[block.name.replace("_", " ")]) # type: ignore

    def onMouseWheel(self, event):
        contentHeight = self.scrollable_frame.winfo_reqheight()
        canvasHeight = self.canvas.winfo_height()

        if contentHeight > canvasHeight:
            self.canvas.yview_scroll(
                int(-1 * (event.delta / 120)),
                "units"
            )
        else:
            self.canvas.yview_moveto(0)

    def updateAvailableBlockList(self) -> None:
        Palette.activeBlockList.clear()
        Palette.disabledBlockList.clear()

        for j, checkButton in enumerate(BlocksWindow.checkButtons):
            if ("selected" in checkButton.state()):
                Palette.activeBlockList.append(Palette.allBlocksList[j])
            else:
                Palette.disabledBlockList.append(Palette.allBlocksList[j])
        
        App.changeProgramMessage(newMessage=f"Blocks saved!\nNew available blocks: {Palette.activeBlockList.__len__()}\nDisabled blocks: {Palette.disabledBlockList.__len__()}")
        self.saveBlockList.configure(text="Saved!")

    def closeSelectBlocksWindow(self) -> None:
        self.parent.selectBlocksWindow = None
        self.destroy()

# Class that is specialized for the color of the minecraft block
class RGBCOLOR():
    def __init__(self, RED: int, GREEN: int, BLUE: int) -> None:
        self.RED = RED
        self.GREEN = GREEN
        self.BLUE = BLUE

    def getColorsAsTuple(self) -> tuple[int, int, int]:
        return (self.RED, self.GREEN, self.BLUE)

# Class that has the average RGB color of the block, the id of the block and the properties of that block (if it has)
class MinecraftBlock():
    def __init__(self, average: RGBCOLOR, rid: str, blockStateProperties: dict[str, str] | None = None, name: str = "") -> None:
        self.average = average
        self.rid = rid
        self.blockStateProperties = blockStateProperties or {}
        self.name = self.rid[10:].replace("waxed_", "")

    def blockStateToString(self) -> str:
        return App.constructStringFromDict(self.blockStateProperties)

    def toNucleationString(self) -> str:
        if not self.blockStateProperties:
            return self.rid

        properties = ",".join(f"{key}={value}" for key, value in self.blockStateProperties.items())
        return f"{self.rid}[{properties}]"

class Palette():
    
    concretePowder: list[MinecraftBlock] = []
    concreteBlocks: list[MinecraftBlock] = []
    woolBlocks: list[MinecraftBlock] = []
    terracottaBlocks: list[MinecraftBlock] = []
    glazedTerracottaBlocks: list[MinecraftBlock] = []
    logBlocks: list[MinecraftBlock] = []
    plankBlocks: list[MinecraftBlock] = []
    allTheOtherBlocks: list[MinecraftBlock] = []

    allBlocksList: list[MinecraftBlock] = []

    activeBlockList: list[MinecraftBlock] = []
    disabledBlockList: list[MinecraftBlock] = []

    @staticmethod
    def updateAllBlocksList() -> None:
        Palette.allBlocksList = Palette.concretePowder + Palette.concreteBlocks + Palette.woolBlocks + Palette.terracottaBlocks + Palette.glazedTerracottaBlocks + Palette.logBlocks + Palette.plankBlocks + Palette.allTheOtherBlocks

# WINDOW SHIT
if __name__ == "__main__":

    print("VERSION 3.3")
    
    main_window = App()
    App.readCSV()
    textures.getTextures() # type: ignore
    BlocksWindow.CreateTextures()
    App.getBlockMatcherDll()
    main_window.mainloop()
