
def disableConcretePowderBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "concrete powder" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disableConcreteBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "concrete" in checkbutton.__getitem__("text") and not "powder" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disableWoolBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "wool" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disableTerracottaBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "terracotta" in checkbutton.__getitem__("text") and not "glazed" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disableGlazedTerracottaBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "glazed terracotta" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disableLogBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "log" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disablePlankBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "planks" in checkbutton.__getitem__("text"):
            # checkbutton.state(["!selected"])
            checkbuttonVars[j].set(0)

def disableOtherBlocks(checkbuttons, checkbuttonVars, otherblocks) -> None:
    startIndex = len(checkbuttons) - len(otherblocks)

    for j in range(startIndex, len(checkbuttons)):
        # checkbuttons[j].state(["!selected"])
        checkbuttonVars[j].set(0)