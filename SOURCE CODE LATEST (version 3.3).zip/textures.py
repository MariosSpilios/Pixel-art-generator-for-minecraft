from __future__ import annotations
import os
import sys
from PIL import Image

Textures: dict = {}
TexturesForSchematicPreview: dict = {}

def resourcePath(relativePath: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        basePath = sys._MEIPASS # type: ignore
    else:
        basePath = os.path.dirname(os.path.abspath(__file__))

    return os.path.join(basePath, relativePath)

def getTextures() -> None:
    for root, _, files in os.walk(resourcePath("texturesFolder")):
        for filename in files:
            Textures[f'{filename.split(".")[0].replace("_", " ")}'] = Image.open(os.path.join(root, filename))

def getTexturesForSchematicPreview() -> None:
    for root, _, files in os.walk(resourcePath("texturesFolder")):
        for filename in files:
            if ("copper" in filename and not "raw" in filename):
                TexturesForSchematicPreview[f'minecraft:waxed_{filename.split(".")[0]}'] = Image.open(os.path.join(root, filename)).convert("RGBA")
            else:
                TexturesForSchematicPreview[f'minecraft:{filename.split(".")[0]}'] = Image.open(os.path.join(root, filename)).convert("RGBA")
    