
def enableConcretePowderBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "concrete powder" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enableConcreteBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "concrete" in checkbutton.__getitem__("text") and not "powder" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enableWoolBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "wool" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enableTerracottaBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "terracotta" in checkbutton.__getitem__("text") and not "glazed" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enableGlazedTerracottaBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "glazed terracotta" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enableLogBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "log" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enablePlankBlocks(checkbuttons, checkbuttonVars) -> None:
    for j, checkbutton in enumerate(checkbuttons):
        if "planks" in checkbutton.__getitem__("text"):
            # checkbutton.state(["selected"])
            checkbuttonVars[j].set(1)

def enableOtherBlocks(checkbuttons, checkbuttonVars, otherblocks) -> None:
    startIndex = len(checkbuttons) - len(otherblocks)

    for j in range(startIndex, len(checkbuttons)):
        # checkbuttons[j].state(["selected"])
        checkbuttonVars[j].set(1)