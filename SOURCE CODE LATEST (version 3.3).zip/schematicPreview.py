from nbtlib import load # type: ignore
import numpy as np
from PIL import Image
from math import ceil, log2
from litemapy.storage import LitematicaBitArray

import textures

def schematicPreview(lastSchematicPath: str):

    if (lastSchematicPath.__len__() == 0):
        return
    if (not textures.TexturesForSchematicPreview):
        textures.getTexturesForSchematicPreview()

    with load(lastSchematicPath) as nbt_file:
        blockStates = nbt_file["Regions"]["Main"]["BlockStates"]
        blockStatePalette = nbt_file["Regions"]["Main"]["BlockStatePalette"]
        bits: int = max(2, ceil(log2(blockStatePalette.__len__())))

        schematicX: int = int(nbt_file["Metadata"]["EnclosingSize"]["x"])
        schematicY: int = int(nbt_file["Metadata"]["EnclosingSize"]["y"])
        schematicZ: int = int(nbt_file["Metadata"]["EnclosingSize"]["z"])
        totalBlocks = schematicX * schematicY * schematicZ

        bitArray = LitematicaBitArray.from_nbt_long_array(blockStates, totalBlocks, bits)
        blockNums = np.fromiter((bitArray[i] for i in range(totalBlocks)), dtype=np.uint32, count=totalBlocks)
        blockNums = blockNums.reshape((int(schematicY), int(schematicZ)))

        paletteTextures = np.zeros((blockStatePalette.__len__(), 16, 16, 4), dtype=np.uint8)

        for i, blockState in enumerate(blockStatePalette):
            blockName = str(blockState["Name"])

            textureImg = textures.TexturesForSchematicPreview.get(blockName)

            if textureImg is not None:
                paletteTextures[i] = np.asarray(textureImg, dtype=np.uint8)

        schematicImage = Image.new("RGBA", (schematicZ*16, schematicY*16), (0, 0, 0, 0))

        for y in range(schematicY):
            rowTextures = paletteTextures[blockNums[y]]

            rowPixels = (rowTextures.transpose(1, 0, 2, 3).reshape(16,schematicZ * 16,4))

            rowImage = Image.fromarray(rowPixels, "RGBA")

            py = (schematicY - 1 - y) * 16
            schematicImage.paste(rowImage, (0, py))

        schematicImage.show()
